#' Jack Watts, s2081957, wattsjack11
#' Add your own function definitions at the top of this file.

#' We shall now define the functions that we shall use in the project.
#' 
#' 
#' 
#'  
#' Log-Exponential density
#'
#' Compute the density or log-density for a Log-Exponential (LogExp)
#' distribution
#'
#' @param x vector of quantiles
#' @param rate vector of rates
#' @param log logical; if TRUE, the log-density is returned

dlogexp <- function(x, rate = 1, log = FALSE) {
  result <- log(rate) + x - rate * exp(x)
  if (!log) {
    exp(result)
  }
  result
}

#' Log-Sum-Exp
#'
#' Convenience function for computing log(sum(exp(x))) in a
#' numerically stable manner
#'
#' @param x numerical vector

log_sum_exp <- function(x) {
  max_x <- max(x, na.rm = TRUE)
  max_x + log(sum(exp(x - max_x)))
}


#' Interval coverage estimation
#'
#' @param CI_method a function object taking arguments x and alpha,
#'   returning a 2-element vector.
#' @param N The number of simulation replications to use for the coverage estimate
#' @param alpha 1-alpha is the intended coverage probability
#' @param n The sample size
#' @param lambda The true lambda values for the Poisson(lambda) model
#'
#' @return A scalar between 0 and 1, estimating the coverage probability
#' for the `CI_method` intervals for the given parameters.

estimate_coverage <- function(CI_method,
                              N = 10000,
                              alpha = 0.1,
                              n = 2,
                              lambda = 3) {
  cover <- 0
  for (loop in seq_len(N)) {
    y <- rpois(n, lambda)
    ci <- CI_method(y, alpha)
    cover <- cover + ((ci[1] <= lambda) && (lambda <= ci[2]))
  }
  cover / N
}


#' Question 1:
#' 
#' 'Resulting Confidence Interval Construction Function'
#' @param y is the obvs
#' @param our key calue for the confidence
#'  
non_approximated_v <- function(y, alpha){
  our_y <- mean(y)
  N <- length(y)
  a <- qnorm(alpha / 2)
  lambda_interval <- c( ((a ^ 2)/(2 * N)) + (( a /(2 * N)) * sqrt(a ^ 2 + 4 * our_y * N)) + our_y,
                        ((a ^ 2)/(2 * N)) - (( a /(2 * N)) * sqrt(a ^ 2 + 4 * our_y * N)) + our_y)
  pmax(lambda_interval, 0)
}

approximated_v <- function(y, alpha){
  confidence_int <- qnorm(c((1 - (alpha / 2)), (alpha / 2)))
  N <- length(y)
  our_t <- mean(y)
  
  lambda1_interval <- (our_t - (sqrt((our_t) / N)) * qnorm(c((1 - (alpha /2)), (alpha /2))))
  pmax(lambda1_interval, 0)
}

estimate_coverage_qn <- function(CI_method,
                                 N = 10000,
                                 alpha = 0.1,
                                 n = 2,
                                 lambda = 3){
  cover_1 <- 0
  cover_2 <- 0
  for (loop in seq_len(N)) {
    y <- rpois(n, lambda)
    ci <- c(CI_method[[1]](y, alpha), CI_method[[2]](y, alpha))
    cover_1 = cover_1 + ((ci[1] <= lambda) && (lambda <= ci[2]))
    cover_2 = cover_2 + ((ci[3] <= lambda) && (lambda <= ci[4]))
  }
  cover = c(cover_1 / N, cover_2 / N)
  
}


estimate_coverage_qn(c(non_approximated_v, approximated_v))


#' Q2
#' We now need to load and plot the data
#' 
#' Prior Density
#' 
#' We will compute the log density, p(theta) of our model
#' 
#' @param theta vector of our parameter values
#' @param params vector of our parameter values of gamma
#' 
log_prior_density <- function(theta, params){
  value <- 
    (dnorm(theta[1],
           sd = params[1],
           mean = 0,
           log = TRUE) +
       
       dnorm(theta[2],
             sd = params[2],
             mean = 1,
             log = TRUE) +
       
       dlogexp(theta[3],
               params[3],
               log = TRUE) +
       
       dlogexp(theta[4],
               params[4],
               log = TRUE))
  
  value
}


#' Observation Likelihood
#' 
#' This will compute our observation likelihood p(y|theta) of our model
#' 
#' @param theta a vector with our parameter values
#' @param x a vector with the CAD weights of our obvs
#' @param y a vector with the the actual weights of our obvs
#' @param params a vector of the parameter values for gamma
#' 
log_like <- function(theta, x, y){
  result <- sum(dnorm(y,
                     sd = sqrt(exp(theta[3]) + exp(theta[4])* x ** 2),
                     mean = (theta[1] + theta[2] * x),
                     log = TRUE))
  result
  
}




#Posterior Density

#We will use this to work out the posterior density p(theta|y) of our model

#' @param theta a vector with our parameter values
#' @param x a vector with the CAD weights of our obvs
#' @param y a vector with the the actual weights of our obvs
#' @param params a vector of the parameter values for gamma
#' 
#' 
log_posterior_density <- function(theta, x, y, params){
  value <- log_prior_density(theta, params = params) + log_like(theta, x, y)
  value
} 



#'Importance Sampling

#'beta_i samples to be created and we calculate the log weights 

#' @param N sample number
#' @param mu the mean vector of the importance distribution
#' @param S the co-variance matrix  
#' 
do_importance <- function(N, mu, S, ...){
  sample_for_x <- rmvnorm(N,
                          sigma = S,
                          mean = mu)
  log_weights1st <- log_posterior_density(sample_for_x, x = x, y = y, params = params) - dmvnorm(sample_for_x, sigma = S, mean = mu, log = TRUE)
  log_weights_main <- log_weights1st - log_sum_exp(log_weights1st)
  
  result = data.frame(beta_1 = sample_for_x[,1],
                      beta_2 = sample_for_x[,2],
                      beta_3 = sample_for_x[,3],
                      beta_4 = sample_for_x[,4],
                      log_weights_main = log_weights_main)
  result
}


make_CI <- function(x, weights){
  alpha = 0.1
  ourquantiles <- wquantile(x,
                         probs = c((alpha / 2), (1 - (alpha / 2))),
                         weights = weights)
  result <- data.frame(Lwr = ourquantiles[1],
                       Upr = ourquantiles[2])
  result
}
